const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const url = "mongodb://localhost:27017";
const client = new MongoClient(url);
const dbName = "todoApp";

app.use(bodyParser.urlencoded({ extended: false }));

let db, todoCollection;

client.connect().then(() => {
  db = client.db(dbName);
  todoCollection = db.collection("todo");
  console.log("Connected to MongoDB");
});

// Serve HTML
app.get("/", async (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// Serve CSS
app.get("/styles.css", (req, res) => {
  res.sendFile(path.join(__dirname, "styles.css"));
});

// Serve JS
app.get("/script.js", (req, res) => {
  res.sendFile(path.join(__dirname, "script.js"));
});

// Send todos as JSON
app.get("/todos", async (req, res) => {
  const todos = await todoCollection.find().sort({ priority: -1 }).toArray();
  res.json(todos);
});

// Add a todo
app.post("/add", async (req, res) => {
  const activity = req.body.activity;
  if (activity.trim() === "") return res.redirect("/");
  await todoCollection.insertOne({ activity, priority: 1 });
  res.redirect("/");
});

// Delete a todo
app.post("/delete", async (req, res) => {
  await todoCollection.deleteOne({ _id: new ObjectId(req.body.id) });
  res.redirect("/");
});

// Change priority
app.post("/priority", async (req, res) => {
  const { id, change } = req.body;
  const todo = await todoCollection.findOne({ _id: new ObjectId(id) });
  if (!todo) return res.redirect("/");
  const newPriority = todo.priority + parseInt(change);
  await todoCollection.updateOne({ _id: new ObjectId(id) }, { $set: { priority: newPriority } });
  res.redirect("/");
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
