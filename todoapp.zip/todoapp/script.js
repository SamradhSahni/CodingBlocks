window.onload = function () {
  fetch("/todos")
    .then((res) => res.json())
    .then((data) => {
      const list = document.getElementById("todo-list");
      list.innerHTML = "";
      data.forEach((todo) => {
        const div = document.createElement("div");
        div.className = "todo-item";
        div.innerHTML = `
          <span>${todo.activity}</span>
          <form class="controls" method="POST" action="/priority">
            <input type="hidden" name="id" value="${todo._id}" />
            <input type="hidden" name="change" value="1" />
            <button>⬆️</button>
          </form>
          <form class="controls" method="POST" action="/priority">
            <input type="hidden" name="id" value="${todo._id}" />
            <input type="hidden" name="change" value="-1" />
            <button>⬇️</button>
          </form>
          <form class="controls" method="POST" action="/delete">
            <input type="hidden" name="id" value="${todo._id}" />
            <button>🗑️</button>
          </form>
        `;
        list.appendChild(div);
      });
    });
};
