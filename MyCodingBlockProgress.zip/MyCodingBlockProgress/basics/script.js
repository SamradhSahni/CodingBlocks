function checkDriving() {
  const age = document.getElementById("ageInput").value;
  const result = document.getElementById("driveResult");

  if (age === "") {
    result.textContent = "Please enter your age.";
    return;
  }

  if (age >= 18) {
    result.textContent = "You are eligible to drive!";
    result.style.color = "green";
  } else {
    result.textContent = "You are NOT eligible to drive.";
    result.style.color = "red";
  }
}


function calculateBMI() {
  const weight = parseFloat(document.getElementById("weight").value);
  const height = parseFloat(document.getElementById("height").value);
  const result = document.getElementById("bmiResult");

  if (!weight || !height || height === 0) {
    result.textContent = "Enter valid weight and height!";
    return;
  }

  const bmi = (weight / (height * height)).toFixed(2);
  result.textContent = `Your BMI is ${bmi}`;

  if (bmi < 18.5) {
    result.textContent += " (Underweight)";
  } else if (bmi >= 18.5 && bmi < 24.9) {
    result.textContent += " (Normal)";
  } else {
    result.textContent += " (Overweight)";
  }
}
