// Practice 1

// 1. Variables and Data Types
let name = "Sam";
let age = 20;
const isStudent = true;
let hobbies = ["coding", "gaming", "reading"];
console.log("Name:", name, "| Age:", age, "| Student:", isStudent);

// 2. Simple Function
function greet(userName) {
  return `Hello, ${userName}! Welcome back.`;
}
console.log(greet("Samradh"));

// 3. Looping Through an Array
for (let i = 0; i < hobbies.length; i++) {
  console.log(`Hobby ${i + 1}: ${hobbies[i]}`);
}

// 4. Object Practice
let student = {
  name: "Riya",
  rollNo: 34,
  marks: {
    math: 88,
    science: 91,
  },
  getTotal: function () {
    return this.marks.math + this.marks.science;
  },
};
console.log("Total Marks:", student.getTotal());

// 5. Conditional Logic
let score = 76;
if (score >= 90) {
  console.log("Grade: A");
} else if (score >= 75) {
  console.log("Grade: B");
} else {
  console.log("Grade: C");
}




