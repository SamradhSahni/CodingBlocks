// jQuery Practice 

$(document).ready(function () {
  $("#todoInput").css("border", "1px solid #aaa");

  // Add Task to List
  $("#addBtn").click(function () {
    let task = $("#todoInput").val().trim();
    if (task !== "") {
      let todoItem = $(`<li class="todo">${task} <button class="deleteBtn"> delete </button></li>`);
      $("#todoList").append(todoItem);
      $("#todoInput").val(""); // clear input
    }
  });

  // Toggle completed class on click
  $("#todoList").on("click", ".todo", function () {
    $(this).toggleClass("completed");
  });

  // Delete a specific task (fade effect)
  $("#todoList").on("click", ".deleteBtn", function (e) {
    e.stopPropagation(); // Stop parent li click event
    $(this).parent().fadeOut(300, function () {
      $(this).remove();
    });
  });

  // Clear all tasks using slide effect
  $("#clearBtn").click(function () {
    $("#todoList").slideUp(300, function () {
      $(this).empty().show();
    });
  });
});
