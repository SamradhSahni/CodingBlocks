const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// for parsing form data
app.use(express.urlencoded({ extended: true }));

// serving static files like CSS, images
app.use(express.static(path.join(__dirname, 'public')));

// home route
app.get('/', (req, res) => {
  res.send('<h1>Welcome to My Express App</h1><a href="/form">Go to Form</a>');
});

// route with params
app.get('/hello/:name', (req, res) => {
  const userName = req.params.name;
  res.send(`Hello, ${userName}!`);
});

// sending a file in response
app.get('/file', (req, res) => {
  res.sendFile(path.join(__dirname, 'files', 'sample.txt'));
});

// rendering static HTML form
app.get('/form', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'form.html'));
});

// reading form data
app.post('/submit', (req, res) => {
  const { name, age } = req.body;
  res.send(`<h3>Received: ${name}, Age: ${age}</h3>`);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
