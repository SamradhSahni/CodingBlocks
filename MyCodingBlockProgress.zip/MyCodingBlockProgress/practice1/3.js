// Practice 2 

// 1. DOM Manipulation
document.body.style.backgroundColor = "#f2f2f2";
const heading = document.createElement("h2");
heading.innerText = "JavaScript Practice Area";
document.body.appendChild(heading);

// 2. Button Click Event
const btn = document.createElement("button");
btn.innerText = "Click Me";
btn.style.padding = "10px";
btn.style.marginTop = "10px";
document.body.appendChild(btn);

btn.addEventListener("click", () => {
  alert("Button was clicked!");
});

// 3. Arrow Function
const double = (n) => n * 2;
console.log("Double of 5 is:", double(5));

// 4. Array Methods
let numbers = [5, 8, 3, 12, 7];
let filtered = numbers.filter((num) => num > 6);
console.log("Numbers > 6:", filtered);

let squared = numbers.map((num) => num * num);
console.log("Squared Numbers:", squared);

// 5. SetTimeout & SetInterval
setTimeout(() => {
  console.log("This runs after 2 seconds");
}, 2000);

let count = 0;
let intervalId = setInterval(() => {
  console.log("Counting:", ++count);
  if (count === 3) clearInterval(intervalId);
}, 1000);


